<?php

define('THEMEROOT', get_stylesheet_directory_url());
define('IMAGES','/wp-content/themes/ADAPTIVE/images');
echo IMAGES;

function regester_my_menus(){
    regester_nav_menus(array(
            'top-menu' => __('Top-menu','Adaptive-framework'),
            'main-menu' => __('Main-menu','Adaptive-framework')
        ));
}
add_action('init', 'regester_my_menus');

?>