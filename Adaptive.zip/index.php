<?php get_header();?>

<p>This is the body content area</p>


<?php get_footer();?>